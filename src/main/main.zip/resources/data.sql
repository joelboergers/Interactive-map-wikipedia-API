INSERT INTO employee(last_name, first_name, city_residence) VALUES('Salahi', 'Nader', 'Saarbrücken');
COMMIT;